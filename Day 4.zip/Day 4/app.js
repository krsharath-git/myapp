var express = require("express");
var bp = require("body-parser");
var app = express();
const db = require("./index.js");
app.use(bp.json());

const collname = 'student'
const dbname = 'myapp'

db.initDb(dbname, collname, function (dbcol) {
    console.log('welcome')
    dbcol.find().toArray(function (err, result) {
        console.log(result)
    })

    app.post('/addUser', (req, res) => {
        var data = req.body
        dbcol.insertOne(data, (error, _result) => {
            dbcol.find().toArray((err, result) => {
                res.json(result)
            })
        })
    })
    app.get('/loaduser/:id', (req, res) => {
        var uid = parseInt(req.params.id);
        console.log(uid)
        dbcol.findOne({ id: uid }, (error, result) => {
            console.log("asad********",result)
        })
        dbcol.findOne({ id: uid }, (error, result) => {
            res.json(result)
        })
    })
    app.put('/updateUser/:id', (req, res) => {
        var uid =  parseInt(req.params.id);
        dbcol.findOne({ id: uid }, (err, result) => {
            const data = req.body
            
            dbcol.updateOne({ id: uid }, { $set: data }, (error, result) => {
                dbcol.find().toArray(function (err, _result) {
                    res.json(_result)
                })
            })
        })

    })

    app.delete('/delete/:id', (req,res) =>{
        var uid = parseInt(req.params.id);
        dbcol.findOne({ id: uid }, (err, result) => {
            const data = req.body
            dbcol.deleteOne({ id: uid }, (error, result) => {
                dbcol.find().toArray(function (err, _result) {
                    res.json(_result)
                })
            })   
    })

})
})
app.listen(3000, () => {
    console.log("Server is ready");
});