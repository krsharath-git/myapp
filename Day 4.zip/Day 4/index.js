const MongoClient = require('mongodb').MongoClient

const url = `mongodb+srv://admin:admin123@cluster0.xmrq7.mongodb.net/myapp?retryWrites=true&w=majority`;
function initDb(
    dbanme,
    collname,
    successcallback,
    failurecallback
){
    MongoClient.connect(url, function(err,dbins) {
        if(err){
            console.log('error', err)
            failurecallback(err)
        } else {
            const dbobj = dbins.db(dbanme);
            const dbcol = dbobj.collection(collname)
            console.log('connected')
            successcallback(dbcol)
        }

    })
}

module.exports = {initDb}
